import test from 'node:test';
import assert from 'node:assert/strict';
import {createSync} from '../src/native-sync.js';
const state=(active)=>({sessions:[],decor:[],settings:{sound:true},active});
test('rapid start, pause, resume, and end leave no stale scheduled notification',async()=>{
 const events=[];let pending=null,stored;
 const sync=createSync({now:()=>100,persist:async v=>{stored=JSON.parse(v);events.push('save');},cancel:async()=>{pending=null;events.push('cancel');},schedule:async a=>{pending=a.endsAt;events.push('schedule');}});
 const first=state({endsAt:500,paused:false});
 const a=sync(first);first.active.endsAt=999;
 const b=sync(state({endsAt:500,paused:true}));
 const c=sync(state({endsAt:800,paused:false}));
 const d=sync(state(null));
 await Promise.all([a,b,c,d]);
 assert.equal(pending,null);assert.equal(stored.active,null);
 assert.deepEqual(events,['save','cancel','schedule','save','cancel','save','cancel','schedule','save','cancel']);
});
test('expired deadlines do not reschedule and failed operations do not poison later saves',async()=>{
 let attempts=0,errors=0,scheduled=0;
 const sync=createSync({now:()=>100,persist:async()=>{if(++attempts===1)throw Error('offline failure');},cancel:async()=>{},schedule:async()=>scheduled++,onError:()=>errors++});
 await sync(state({endsAt:200,paused:false}));
 await sync(state({endsAt:90,paused:false}));
 await sync(state({endsAt:300,paused:false}));
 assert.equal(errors,1);assert.equal(attempts,3);assert.equal(scheduled,1);
});
