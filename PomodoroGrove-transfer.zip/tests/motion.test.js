import test from 'node:test';import assert from 'node:assert/strict';
import {loadPlantArt,drawPlant,setWindTime} from '../src/art.js';
import {categories} from '../src/core.js';
test('all four plants sway gently with rooted bases, and motion can stop',async()=>{
 globalThis.Image=class{naturalWidth=100;naturalHeight=140;set src(v){queueMicrotask(()=>this.onload());}};
 await loadPlantArt();
 for(const [category,cat] of Object.entries(categories)){
 const transforms=[];const c={save(){},restore(){},translate(){},drawImage(){},transform(...m){transforms.push(m);}};
 setWindTime(0,true);drawPlant(c,{category,species:cat.species[0],seed:5});setWindTime(2,true);drawPlant(c,{category,species:cat.species[0],seed:5});
 assert.equal(transforms.length,2);assert.notEqual(transforms[0][2],transforms[1][2]);for(const m of transforms){assert.ok(Math.abs(m[2])<.05);assert.deepEqual([m[0],m[1],m[3],m[4],m[5]],[1,0,1,0,0]);}
 setWindTime(3,false);drawPlant(c,{category,species:cat.species[0],seed:5});assert.equal(transforms.length,2);
 }
 delete globalThis.Image;
});
