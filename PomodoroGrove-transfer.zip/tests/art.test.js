import test from 'node:test';
import assert from 'node:assert/strict';
import {categories} from '../src/core.js';
import {drawPlant} from '../src/art.js';

function fakeCanvas(){
 let ellipses=0,strokes=0;
 const context={
  save(){},restore(){},translate(){},scale(){},beginPath(){},closePath(){},moveTo(){},lineTo(){},quadraticCurveTo(){},arc(){},
  ellipse(){ellipses++;},fill(){},stroke(){strokes++;}
 };
 return {context,counts:()=>({ellipses,strokes})};
}
test('all 18 varieties render with offline storybook vector art',()=>{
 for(const [category,config] of Object.entries(categories))for(const species of config.species){
  const {context,counts}=fakeCanvas();
  assert.doesNotThrow(()=>drawPlant(context,{category,species,seed:42,x:0,y:0}));
  assert.ok(counts().ellipses>6,`${species} should draw illustrated shapes`);
  assert.ok(counts().strokes>4,`${species} should have outlines`);
 }
});
test('fruit trees feature several large fruit shapes with faces',()=>{
 const {context,counts}=fakeCanvas();
 drawPlant(context,{category:'reading',species:'Peach',seed:5});
 assert.ok(counts().ellipses>50,'tree includes canopy, large fruits, and expressive faces');
});
