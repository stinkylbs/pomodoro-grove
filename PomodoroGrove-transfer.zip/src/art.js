import {random,decorCatalog} from './core.js';
import {drawStorybookPlant} from './storybook-art.js';

let theme='peach',windTime=0,windEnabled=true;
export function setWindTime(time,enabled=true){windTime=time;windEnabled=enabled;}
function sway(c,p){if(!windEnabled)return;const phase=((p.seed||37)%997)/997*Math.PI*2,amp={vocabulary:.035,reading:.016,philosophy:.013,news:.024}[p.category]||.02;c.transform(1,0,Math.sin(windTime*1.2+phase)*amp+Math.sin(windTime*.57+phase)*amp*.25,1,0,0);}
export function setArtTheme(value){theme=value;}

// These are the hand-drawn/crayon sprites from the approved Pomodoro Grove asset board.
// Existing save files can still contain the older species names, so aliases intentionally
// point those names at the closest sprite rather than invalidating the user's garden.
const plantSources={
 vocabulary:{
  Daisy:'assets/storybook/vocabulary-sunny.webp',
  Tulip:'assets/storybook/vocabulary-tulip.webp',
  Lavender:'assets/storybook/vocabulary-sky.webp',
  Poppy:'assets/storybook/vocabulary-blush.webp',
  Sunflower:'assets/storybook/vocabulary-starry.webp',
  Cosmos:'assets/storybook/vocabulary-clover.webp',
  Sunny:'assets/storybook/vocabulary-sunny.webp',
  Blush:'assets/storybook/vocabulary-blush.webp',
  Sky:'assets/storybook/vocabulary-sky.webp',
  Clover:'assets/storybook/vocabulary-clover.webp',
  Starry:'assets/storybook/vocabulary-starry.webp'
 },
 reading:{
  Apple:'assets/storybook/reading-apple.webp',
  Pear:'assets/storybook/reading-orange.webp',
  Orange:'assets/storybook/reading-orange.webp',
  Peach:'assets/storybook/reading-peach.webp',
  Cherry:'assets/storybook/reading-cherry.webp',
  Lemon:'assets/storybook/reading-lemon.webp',
  Plum:'assets/storybook/reading-peach.webp'
 },
 philosophy:{
  'English oak':'assets/storybook/philosophy-oak.webp',
  'White oak':'assets/storybook/philosophy-ginkgo.webp',
  'Red oak':'assets/storybook/philosophy-cherry.webp',
  'Cork oak':'assets/storybook/philosophy-oak.webp',
  'Bur oak':'assets/storybook/philosophy-cherry.webp',
  'Willow oak':'assets/storybook/philosophy-ginkgo.webp',
  Oak:'assets/storybook/philosophy-oak.webp',
  Cherry:'assets/storybook/philosophy-cherry.webp',
  Ginkgo:'assets/storybook/philosophy-ginkgo.webp'
 },
 news:{
  Blueberry:'assets/storybook/news-blueberry.webp',
  Raspberry:'assets/storybook/news-raspberry.webp',
  Blackberry:'assets/storybook/news-grape.webp',
  Gooseberry:'assets/storybook/news-strawberry.webp',
  Redcurrant:'assets/storybook/news-raspberry.webp',
  Elderberry:'assets/storybook/news-grape.webp',
  Strawberry:'assets/storybook/news-strawberry.webp',
  Grape:'assets/storybook/news-grape.webp'
 }
};
const growthSources={
 Seed:'assets/storybook/growth-seed.webp',
 Sprout:'assets/storybook/growth-sprout.webp',
 Bud:'assets/storybook/growth-bud.webp',
 Growing:'assets/storybook/growth-growing.webp',
 Bloom:'assets/storybook/growth-bloom.webp'
};
const plantImages=new Map(),growthImages=new Map();
const decorImages=new Map();
let loadPromise=null;
const sourceImages=new Map();

function loadImage(src){
 if(sourceImages.has(src))return sourceImages.get(src);
 const job=new Promise(resolve=>{
  const image=new Image();
  image.decoding='async';
  image.onload=()=>{try{const canvas=document.createElement('canvas');canvas.width=image.naturalWidth;canvas.height=image.naturalHeight;const ctx=canvas.getContext('2d');ctx.drawImage(image,0,0);const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data;let l=canvas.width,t=canvas.height,r=0,b=0;for(let y=0;y<canvas.height;y++)for(let x=0;x<canvas.width;x++)if(pixels[(y*canvas.width+x)*4+3]>8){l=Math.min(l,x);r=Math.max(r,x);t=Math.min(t,y);b=Math.max(b,y);}if(r>=l&&b>=t)image.ink={x:l,y:t,w:r-l+1,h:b-t+1};}catch{}resolve(image);};
  image.onerror=()=>resolve(null);
  image.src=src;
 });
 sourceImages.set(src,job);return job;
}

export async function loadPlantArt(){
 if(loadPromise)return loadPromise;
 if(typeof Image==='undefined')return;
 loadPromise=(async()=>{
  const jobs=[];
  for(const [category,species] of Object.entries(plantSources))for(const [name,src] of Object.entries(species)){
   const key=`${category}:${name}`;
   if(plantImages.has(key))continue;
   jobs.push(loadImage(src).then(image=>{if(image)plantImages.set(key,image);}));
  }
  for(const [stage,src] of Object.entries(growthSources))jobs.push(loadImage(src).then(image=>{if(image)growthImages.set(stage,image);}));
  for(const [kind,src] of Object.entries({"small-fountain": "assets/storybook/decor-small-fountain.webp", "fountain": "assets/storybook/decor-fountain.webp", "well": "assets/storybook/decor-well.webp", "stone-well": "assets/storybook/decor-stone-well.webp", "bird-bath": "assets/storybook/decor-bird-bath.webp", "lily-pond": "assets/storybook/decor-lily-pond.webp", "duck-pond": "assets/storybook/decor-duck-pond.webp", "little-bridge": "assets/storybook/decor-little-bridge.webp", "rose-arch": "assets/storybook/decor-rose-arch.webp", "trellis": "assets/storybook/decor-trellis.webp", "pergola": "assets/storybook/decor-pergola.webp", "tiny-greenhouse": "assets/storybook/decor-tiny-greenhouse.webp", "hedge": "assets/storybook/decor-hedge.webp", "arbor": "assets/storybook/decor-arbor.webp", "gazebo": "assets/storybook/decor-gazebo.webp", "large-pond": "assets/storybook/decor-large-pond.webp", "elaborate-fountain": "assets/storybook/decor-elaborate-fountain.webp", "greenhouse": "assets/storybook/decor-greenhouse.webp", "windmill": "assets/storybook/decor-windmill.webp", "clock-tower": "assets/storybook/decor-clock-tower.webp", "cottage": "assets/storybook/decor-cottage.webp", "stone-bridge": "assets/storybook/decor-stone-bridge.webp", "giant-arch": "assets/storybook/decor-giant-arch.webp"}))jobs.push(loadImage(src).then(image=>{if(image)decorImages.set(kind,image);}));
  await Promise.all(jobs);
 })();
 return loadPromise;
}

function ellipse(c,x,y,rx,ry,color){c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,0,0,Math.PI*2);c.fill();}
function line(c,x,y,xx,yy,color,width=2){c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.beginPath();c.moveTo(x,y);c.lineTo(xx,yy);c.stroke();}

export const baseHeight={vocabulary:78,reading:120,philosophy:132,news:92};
export function plantBounds(p,scale=1){const image=plantImages.get(`${p.category}:${p.species}`);const h=baseHeight[p.category]*scale,w=h*(image?(image.ink?.w||image.naturalWidth)/(image.ink?.h||image.naturalHeight):1);return {left:(p.x||0)-w/2,right:(p.x||0)+w/2,top:(p.y||0)-h,bottom:p.y||0};}
export function drawPlantInBox(c,p,x,y,w,h){const bounds=plantBounds({...p,x:0,y:0});const scale=Math.min(w/(bounds.right-bounds.left),h/(-bounds.top));drawPlant(c,{...p,x:x+w/2,y:y+h},scale);}
function drawImageBottom(c,image,height,ghost=false){
 const ratio=(image.ink?.w||image.naturalWidth)/(image.ink?.h||image.naturalHeight),width=height*ratio;
 c.save();
 if(ghost)c.globalAlpha=.68;
 c.imageSmoothingEnabled=true;
 const b=image.ink||{x:0,y:0,w:image.naturalWidth,h:image.naturalHeight};c.drawImage(image,b.x,b.y,b.w,b.h,-width/2,-height,width,height);
 c.restore();
}

export function drawPlant(c,p,scale=1,ghost=false){
 const image=plantImages.get(`${p.category}:${p.species}`);
 if(image&&typeof c.drawImage==='function'){
  c.save();c.translate(p.x||0,p.y||0);sway(c,p);drawImageBottom(c,image,baseHeight[p.category]*scale,ghost);c.restore();return;
 }
 // Canvas-vector fallback is retained for tests and for the extremely rare failed image load.
 return drawStorybookPlant(c,p,scale,ghost);
}

export function drawGrowthStage(c,stage,x=0,y=0,scale=1,ghost=false){
 const image=growthImages.get(stage);
 if(!image||typeof c.drawImage!=='function')return false;
 const stageHeight={Seed:54,Sprout:62,Bud:82,Growing:102,Bloom:114}[stage]||88;
 c.save();c.translate(x,y);sway(c,{category:'vocabulary',seed:99});drawImageBottom(c,image,stageHeight*scale,ghost);c.restore();return true;
}

export function drawDecor(c,p,scale=1){c.save();c.translate(p.x,p.y);c.scale(scale,scale);if(p.kind==='butterfly'){line(c,0,-13,0,-20,'#745445',1);ellipse(c,-4,-18,4,5,'#f7a7c8');ellipse(c,4,-18,4,5,'#c9a7ef');ellipse(c,-3,-12,3,3,'#fac4d5');ellipse(c,3,-12,3,3,'#dcc6f4');}else if(p.kind==='mushroom'){line(c,0,0,0,-7,'#745445',3);ellipse(c,0,-8,6,4,'#f0a49b');ellipse(c,-2,-9,1,1,'#fff6e7');ellipse(c,2,-8,1,1,'#fff6e7');}else ellipse(c,0,0,6,3,'#b8beb0');c.restore();}
export function drawTerrain(c,count){const size=Math.max(176,Math.sqrt(count)*56);const r=random(568);c.save();c.scale(1,.66);const shadow=c.createRadialGradient(0,8,0,0,8,size*1.02);shadow.addColorStop(0,'#00000010');shadow.addColorStop(1,'#00000000');ellipse(c,0,8,size*1.04,size*.84,shadow);const gradient=c.createRadialGradient(0,-12,size*.06,0,0,size);gradient.addColorStop(0,theme==='sunshine'?'#d8efb7':theme==='lilac'?'#caead4':'#d2eebd');gradient.addColorStop(.58,theme==='sunshine'?'#c1e08d':theme==='lilac'?'#b8ddb9':'#bfe39a');gradient.addColorStop(.9,theme==='sunshine'?'#a7cf70':theme==='lilac'?'#9cca9b':'#a9d17f');gradient.addColorStop(1,'#96bf6f00');ellipse(c,0,0,size,size*.78,gradient);ellipse(c,-size*.12,-6,size*.55,size*.28,'#dff3c3aa',null);ellipse(c,size*.15,10,size*.52,size*.26,'#9bcf78aa',null);for(let i=0;i<Math.max(44,count*2.4);i++){const a=r()*Math.PI*2,rad=Math.sqrt(r())*size*.82,x=Math.cos(a)*rad,y=Math.sin(a)*rad*.78;line(c,x,y,x-2-r()*1.5,y-4-r()*2,'#7eb86d44',1);line(c,x,y,x+1+r()*1.5,y-5-r()*2,'#b5db8c55',1);if(r()>.87){ellipse(c,x+(r()*8-4),y+(r()*6-3),1.8,1.8,r()>.5?'#ffd8e4aa':'#fff0b4aa',null);}}c.restore();}

export function decorBounds(p,scale=1){const item=decorCatalog.find(i=>i.id===p.kind),h=(item?.height||100)*scale;const image=decorImages.get(p.kind),w=item?.group==='paths'?60*scale:image?h*(image.ink?.w||image.naturalWidth)/(image.ink?.h||image.naturalHeight):h;return {left:p.x-w/2,right:p.x+w/2,top:p.y-h,bottom:p.y};}
export function drawShopDecor(c,p,scale=1){
 const image=decorImages.get(p.kind),item=decorCatalog.find(i=>i.id===p.kind);c.save();c.translate(p.x,p.y);
 if(image){drawImageBottom(c,image,(item?.height||100)*scale);}
 else if(item?.group==='paths')drawPath(c,p.kind,scale);
 c.restore();
}
function drawPath(c,kind,scale){c.scale(scale,scale);const block=(x,y,w,h,color)=>{c.fillStyle=color;c.fillRect(x,y,w,h);};
 if(kind==='puddle'){ellipse(c,0,-10,29,10,'#88749d');ellipse(c,0,-11,26,8,'#9adee7');block(-15,-15,14,2,'#e4fcf6');block(7,-10,10,2,'#c9f1f1');return;}
 if(kind==='moss-stones'){for(const [x,y,rx,ry] of [[-17,-15,11,7],[7,-20,11,6],[17,-7,11,6]]){ellipse(c,x,y,rx,ry,'#8a7891');ellipse(c,x,y-1,rx-2,ry-2,'#d0cdd6');ellipse(c,x-3,y-2,rx*.5,ry*.4,'#a3bf8c');}return;}
 block(-30,-26,60,26,'#967892');block(-28,-24,56,22,kind==='wood-tiles'?'#eac0a0':kind==='cobblestone'?'#c5b6ca':kind==='flower-border'?'#b8d89d':'#efb0ad');
 if(kind==='flower-border'){for(let i=0;i<6;i++){const x=-23+i*9,y=-12+(i%2)*3;line(c,x,y+6,x,y,'#7b9b6c',2);ellipse(c,x,y,4,4,i%2?'#edd8fd':'#f6b4cf');ellipse(c,x,y,1.5,1.5,'#fff1a8');}return;}
 if(kind==='wood-tiles'){for(let y=-20;y<-2;y+=7){block(-28,y,56,2,'#bc9397');block(-24,y-2,3,1,'#886a83');block(21,y-2,3,1,'#886a83');}return;}
 if(kind==='cobblestone'){for(let row=0;row<2;row++)for(let col=0;col<4;col++){const x=-22+col*14+(row%2)*2,y=-19+row*11;ellipse(c,x,y,6,4.5,'#8f809a');ellipse(c,x,y-1,5,3,'#ddd4df');}return;}
 block(-27,-23,54,3,'#f8d4b5');block(-27,-13,54,3,'#bd828f');block(-9,-23,3,10,'#bd828f');block(12,-10,3,7,'#bd828f');
}
export function drawWeather(c,w,h,weather,time,motion=true){
 if(weather==='clear')return;c.save();const t=motion?time:0;
 for(let i=0;i<(weather==='fireflies'?18:36);i++){const seed=(i*7919)%997,x0=(seed/997)*w,y0=((i*193)%997)/997*h;
 if(weather==='rain'){const y=(y0+t*55)%h,x=(x0-t*9%w+w)%w;line(c,x,y,x-3,y+9,'#a3cadb88',1.3);}
 else if(weather==='snow'){const y=(y0+t*10)%h,x=x0+Math.sin(t*.7+i)*9;ellipse(c,x,y,1.6+i%2,1.6+i%2,'#fff8f3bb');}
 else if(weather==='leaves'){const y=(y0+t*12)%h,x=x0+Math.sin(t+i)*15;c.save();c.translate(x,y);c.rotate(Math.sin(t*.7+i)*.5);ellipse(c,0,0,3,1.8,i%2?'#e9a28e99':'#f1ce8999');c.restore();}
 else {const y=h*.4+(y0*.55)+Math.sin(t*.6+i)*6,x=x0+Math.sin(t*.45+i)*7;c.globalAlpha=.3+(Math.sin(t*1.3+i)+1)*.25;ellipse(c,x,y,2,2,'#f9f2a8');}
 }c.restore();
}
