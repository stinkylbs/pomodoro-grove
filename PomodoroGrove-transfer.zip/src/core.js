export const categories = {
 vocabulary: {label:'Vocabulary',plant:'Flowers',color:'#d875a5',species:['Sunny','Blush','Sky','Clover','Starry','Tulip']},
 reading: {label:'Casual Reading',plant:'Fruit trees',color:'#df9a45',species:['Apple','Orange','Peach','Cherry','Lemon']},
 philosophy: {label:'Philosophy',plant:'Book trees',color:'#55a58a',species:['Oak','Cherry','Ginkgo']},
 news: {label:'News',plant:'Berry bushes',color:'#8c83d1',species:['Blueberry','Raspberry','Strawberry','Grape']}
};
export function dayKey(time) {const d=new Date(time); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
export function todaySessions(sessions,now=Date.now()){return sessions.filter(s=>dayKey(s.completedAt)===dayKey(now));}
export function progress(sessions,now=Date.now()){const today=todaySessions(sessions,now);return {count:today.length,balanced:Object.keys(categories).every(c=>today.some(s=>s.category===c)),types:new Set(today.map(s=>s.category))};}
export const DAILY_GOAL=4;
export function unlockedSpecies(category){return [...categories[category].species];}
const oldSeeds={Daisy:'Sunny',Lavender:'Sky',Poppy:'Blush',Sunflower:'Starry',Cosmos:'Clover',Pear:'Orange',Plum:'Peach','English oak':'Oak','Cork oak':'Oak','White oak':'Ginkgo','Willow oak':'Ginkgo','Red oak':'Cherry','Bur oak':'Cherry',Blackberry:'Grape',Gooseberry:'Strawberry',Redcurrant:'Raspberry',Elderberry:'Grape'};
export function pickSpecies(category,sessions,choice=null,rng=Math.random){if(categories[category].species.includes(choice))return choice;const previous=sessions.filter(s=>s.category===category).at(-1)?.species;const pool=categories[category].species.filter(name=>name!==(oldSeeds[previous]||previous));return pool[Math.floor(rng()*pool.length)];}
export function sessionReward(sessions,now=Date.now(),category){const p=progress(sessions,now);return p.balanced?20:p.types.size===DAILY_GOAL-1&&!p.types.has(category)&&categories[category]?102:2;}
export function random(seed){let a=seed>>>0;return ()=>{a+=0x6D2B79F5;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296;};}
export function position(index){const radius=47*Math.sqrt(index),angle=index*2.3999632297;return {x:Math.cos(angle)*radius,y:Math.sin(angle)*radius*.65};}
export function makeSession(category,seconds,sessions,now=Date.now(),seed=Math.floor(Math.random()*1e9),choice=null){if(!categories[category]||seconds<0)throw new Error('Invalid session');return {id:`${now}-${seed}`,category,seconds,completedAt:now,seed,species:pickSpecies(category,sessions,choice,random(seed)),earned:sessionReward(sessions,now,category),...position(sessions.length)};}
export function rewards(before,after,now){const p=progress(before,now),next=progress(after,now),session=after.at(-1);const gifts=[];if(!p.balanced&&next.balanced)gifts.push({id:session.id+'-balance',kind:'butterfly',sessionId:session.id,x:session.x+26,y:session.y-4,seed:session.seed});if(next.count>DAILY_GOAL&&random(session.seed+6)()>.4)gifts.push({id:session.id+'-bonus',kind:random(session.seed+8)()>.5?'mushroom':'stone',sessionId:session.id,x:session.x-18,y:session.y+10,seed:session.seed});return gifts;}
export function remaining(active,now=Date.now()){return !active?0:active.paused?active.remainingMs:Math.max(0,active.endsAt-now);}
export function sampleGarden(){const sessions=[],decor=[],keys=Object.keys(categories);for(let i=0;i<96;i++){const category=keys[i%keys.length];const now=Date.now()-(24-Math.floor(i/keys.length))*86400000;const s=makeSession(category,1500,sessions,now,2348+i*7919);const before=[...sessions];sessions.push(s);decor.push(...rewards(before,sessions,now));}return {sessions,decor};}

// One of each category completes the daily goal: base 2, goal bonus 100, then 20.
export const decorCatalog=[
 {
  "id": "brick",
  "name": "Brick tiles",
  "price": 10,
  "group": "paths",
  "height": 26,
  "description": "Peach bricks for little garden lanes."
 },
 {
  "id": "cobblestone",
  "name": "Cobblestone",
  "price": 12,
  "group": "paths",
  "height": 26,
  "description": "A softly rounded stone path."
 },
 {
  "id": "moss-stones",
  "name": "Mossy stepping stones",
  "price": 14,
  "group": "paths",
  "height": 26,
  "description": "Soft green stepping stones."
 },
 {
  "id": "flower-border",
  "name": "Flower-border tiles",
  "price": 16,
  "group": "paths",
  "height": 28,
  "description": "Tiny flowers to line your paths."
 },
 {
  "id": "wood-tiles",
  "name": "Wooden tiles",
  "price": 12,
  "group": "paths",
  "height": 26,
  "description": "Warm wooden garden decking."
 },
 {
  "id": "puddle",
  "name": "Tiny puddles",
  "price": 8,
  "group": "paths",
  "height": 22,
  "description": "A little patch of reflected sky."
 },
 {
  "id": "small-fountain",
  "name": "Small fountain",
  "price": 45,
  "group": "water",
  "height": 64,
  "description": "A small splash for a cozy corner."
 },
 {
  "id": "fountain",
  "name": "Tiered fountain",
  "price": 90,
  "group": "water",
  "height": 100,
  "description": "Two tiers of tumbling pastel water."
 },
 {
  "id": "well",
  "name": "Wishing well",
  "price": 60,
  "group": "water",
  "height": 100,
  "description": "A quiet place to make a wish."
 },
 {
  "id": "stone-well",
  "name": "Stone well",
  "price": 55,
  "group": "water",
  "height": 68,
  "description": "A mossy well with an old bucket."
 },
 {
  "id": "bird-bath",
  "name": "Bird bath",
  "price": 40,
  "group": "water",
  "height": 65,
  "description": "A little landing place for visitors."
 },
 {
  "id": "lily-pond",
  "name": "Lily pond",
  "price": 80,
  "group": "water",
  "height": 48,
  "description": "Floating lilies and still blue water."
 },
 {
  "id": "duck-pond",
  "name": "Duck pond",
  "price": 100,
  "group": "water",
  "height": 55,
  "description": "A tiny home for cheerful ducks."
 },
 {
  "id": "little-bridge",
  "name": "Little bridge",
  "price": 70,
  "group": "water",
  "height": 55,
  "description": "A wooden crossing for your garden."
 },
 {
  "id": "rose-arch",
  "name": "Rose arch",
  "price": 100,
  "group": "structures",
  "height": 120,
  "description": "A doorway threaded with pink roses."
 },
 {
  "id": "trellis",
  "name": "Trellis",
  "price": 50,
  "group": "structures",
  "height": 100,
  "description": "A lattice for climbing vines."
 },
 {
  "id": "pergola",
  "name": "Pergola",
  "price": 150,
  "group": "structures",
  "height": 125,
  "description": "A leafy shelter for slow afternoons."
 },
 {
  "id": "tiny-greenhouse",
  "name": "Tiny greenhouse",
  "price": 120,
  "group": "structures",
  "height": 95,
  "description": "A little glass home for seedlings."
 },
 {
  "id": "hedge",
  "name": "Hedges",
  "price": 30,
  "group": "structures",
  "height": 52,
  "description": "A soft green border for a secret nook."
 },
 {
  "id": "arbor",
  "name": "Little arbor",
  "price": 110,
  "group": "structures",
  "height": 110,
  "description": "A cozy vine-covered garden seat."
 },
 {
  "id": "gazebo",
  "name": "Gazebo",
  "price": 300,
  "group": "landmarks",
  "height": 150,
  "description": "A centerpiece for your dream garden."
 },
 {
  "id": "large-pond",
  "name": "Large pond",
  "price": 260,
  "group": "landmarks",
  "height": 85,
  "description": "Room for reeds, lilies, and daydreams."
 },
 {
  "id": "elaborate-fountain",
  "name": "Elaborate fountain",
  "price": 360,
  "group": "landmarks",
  "height": 150,
  "description": "An ornate fountain worth saving for."
 },
 {
  "id": "greenhouse",
  "name": "Greenhouse",
  "price": 320,
  "group": "landmarks",
  "height": 145,
  "description": "A spacious glass garden sanctuary."
 },
 {
  "id": "windmill",
  "name": "Windmill",
  "price": 380,
  "group": "landmarks",
  "height": 160,
  "description": "A cheerful landmark above the grove."
 },
 {
  "id": "clock-tower",
  "name": "Clock tower",
  "price": 450,
  "group": "landmarks",
  "height": 175,
  "description": "A little tower to mark quiet hours."
 },
 {
  "id": "cottage",
  "name": "Tiny cottage fa\u00e7ade",
  "price": 400,
  "group": "landmarks",
  "height": 140,
  "description": "A welcoming doorway into your world."
 },
 {
  "id": "stone-bridge",
  "name": "Stone bridge",
  "price": 280,
  "group": "landmarks",
  "height": 95,
  "description": "A generous arch over a pond or path."
 },
 {
  "id": "giant-arch",
  "name": "Giant flowering arch",
  "price": 350,
  "group": "landmarks",
  "height": 165,
  "description": "A grand entrance full of blossoms."
 }
];
export const biomeCatalog=[
 {
  "id": "meadow",
  "name": "Sunny Meadow",
  "price": 0,
  "weather": "clear",
  "time": "day",
  "description": "Butter-yellow sunshine and mint grass."
 },
 {
  "id": "twilight",
  "name": "Peach Twilight",
  "price": 150,
  "weather": "clear",
  "time": "dusk",
  "description": "Lavender hills in a peach-pink sunset."
 },
 {
  "id": "moonlight",
  "name": "Moonlit Grove",
  "price": 200,
  "weather": "fireflies",
  "time": "night",
  "description": "A starry blue night with gentle fireflies."
 },
 {
  "id": "rain",
  "name": "Rainy Woodland",
  "price": 180,
  "weather": "rain",
  "time": "day",
  "description": "A cool woodland clearing with soft rain."
 },
 {
  "id": "snow",
  "name": "Snowdrop Valley",
  "price": 220,
  "weather": "snow",
  "time": "day",
  "description": "Powdery snowflakes over a pastel valley."
 },
 {
  "id": "autumn",
  "name": "Golden Autumn",
  "price": 180,
  "weather": "leaves",
  "time": "dusk",
  "description": "Peach leaves drifting in golden evening light."
 }
];
export function dewdrops(state){return Math.max(0,state.sessions.reduce((sum,s)=>sum+(Number.isFinite(s.earned)?s.earned:Math.floor(s.seconds/60)),0)-(state.decorShop?.spent||0));}
export function buyDecoration(state,id,free=false){const item=decorCatalog.find(i=>i.id===id);if(!item||(!free&&dewdrops(state)<item.price))return false;state.decorShop.spent+=free?0:item.price;state.decorShop.inventory[id]=(state.decorShop.inventory[id]||0)+1;return true;}
export function placeDecoration(state,kind,x,y,id){if(!Number.isFinite(x)||!Number.isFinite(y)||!(state.decorShop.inventory[kind]>0))return false;state.decorShop.inventory[kind]--;state.decor.push({id,kind,x,y,purchased:true});return true;}
export function storeDecoration(state,id){const index=state.decor.findIndex(d=>d.id===id&&d.purchased);if(index<0)return false;const [item]=state.decor.splice(index,1);state.decorShop.inventory[item.kind]=(state.decorShop.inventory[item.kind]||0)+1;return true;}

export function buyBiome(state,id,free=false){const item=biomeCatalog.find(b=>b.id===id);if(!item||state.biomes.owned.includes(id)||(!free&&dewdrops(state)<item.price))return false;state.decorShop.spent+=free?0:item.price;state.biomes.owned.push(id);return true;}

export function practiceSummary(sessions,now=Date.now()){
 const yesterday=new Date(now);yesterday.setDate(yesterday.getDate()-1);
 const summarize=list=>({plants:list.length,minutes:Math.round(list.reduce((sum,s)=>sum+s.seconds,0)/60),types:new Set(list.map(s=>s.category)).size});
 return {total:summarize(sessions),today:summarize(todaySessions(sessions,now)),yesterday:summarize(todaySessions(sessions,yesterday.getTime()))};
}
export const biomeImages={meadow:'assets/storybook/meadow-background.webp',twilight:'assets/storybook/biome-twilight.webp',moonlight:'assets/storybook/biome-moonlight.webp',rain:'assets/storybook/biome-rain.webp',snow:'assets/storybook/biome-snow.webp',autumn:'assets/storybook/biome-autumn.webp'};
