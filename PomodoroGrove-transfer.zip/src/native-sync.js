export function createSync({persist,cancel,schedule,now=Date.now,onError=()=>{}}){
 let queue=Promise.resolve();
 return state=>{const snapshot=JSON.parse(JSON.stringify(state));
  queue=queue.catch(()=>{}).then(async()=>{
   await persist(JSON.stringify(snapshot));
   await cancel();
   const a=snapshot.active;
   if(a&&!a.paused&&a.endsAt>now())await schedule(a,snapshot.settings.sound);
  }).catch(onError);
  return queue;
 };
}
