import {categories,practiceSummary,biomeImages,pickSpecies,DAILY_GOAL,dayKey,todaySessions,progress,unlockedSpecies,makeSession,rewards,remaining,sampleGarden,decorCatalog,dewdrops,buyDecoration,placeDecoration,storeDecoration,biomeCatalog,buyBiome} from './core.js';
import {drawPlant,drawGrowthStage,drawDecor,drawTerrain,setArtTheme,loadPlantArt,plantBounds,drawPlantInBox,baseHeight,drawShopDecor,decorBounds,setWindTime,drawWeather} from './art.js';
const TEST_MODE=window.GROVE_TEST_MODE===true;
const $=id=>document.getElementById(id),KEY=TEST_MODE?'little-grove-test-v6':'little-grove-v1';
let state={sessions:[],decor:[],active:null,settings:{minutes:25,sound:true,theme:'peach'}},storageOK=true;
try{const saved=JSON.parse((localStorage.getItem(KEY)||(TEST_MODE?localStorage.getItem('little-grove-v1'):null)));if(saved&&Array.isArray(saved.sessions)&&Array.isArray(saved.decor)&&saved.settings){state=saved;state.sessions=state.sessions.filter(s=>categories[s.category]&&Number.isFinite(s.completedAt)&&Number.isFinite(s.seed));if(state.active&&state.active.kind!=='break'&&!categories[state.active.category])state.active=null;}}catch{storageOK=false;}
// Keep the superseded plant-shop save as a backup; its spending does not reduce Dewdrops.
state.decorShop??={spent:0,inventory:{}};
state.decorShop.spent=Number.isFinite(state.decorShop.spent)?Math.max(0,state.decorShop.spent):0;
state.decorShop.inventory??={};
state.biomes??={owned:['meadow'],active:'meadow'};
state.biomes.owned=Array.isArray(state.biomes.owned)?state.biomes.owned:['meadow'];if(!state.biomes.owned.includes('meadow'))state.biomes.owned.push('meadow');
if(!state.biomes.owned.includes(state.biomes.active)||!biomeCatalog.some(b=>b.id===state.biomes.active))state.biomes.active='meadow';
state.settings.motion??=true;
if(state.active?.preview&&!TEST_MODE)state.active=null;
let animationTime=0,previewBiome=null;function currentBiome(){return biomeCatalog.find(b=>b.id===(previewBiome||state.biomes.active));}const reducedMotion=window.matchMedia?.('(prefers-reduced-motion: reduce)');
function motionOn(){return state.settings.motion&&!reducedMotion?.matches;}
function applyBiome(){const b=currentBiome();document.body.dataset.biome=b.id;for(const id of ['today-background','world-background']){const img=$(id);if(img.dataset.biome!==b.id){img.src=biomeImages[b.id];img.dataset.biome=b.id;}}$('biome-status').textContent=(previewBiome?'Preview · ':'')+b.name+' · '+b.time+' · '+b.weather;$('exit-biome-preview').hidden=!previewBiome;}
function weather(c,w,h){drawWeather(c,w,h,currentBiome().weather,animationTime,motionOn());}

state.seedChoices??={};
function chosenSpecies(category){return state.seedChoices[category]||categories[category].species[0];}
let shopFilter='all',placing=null,editGarden=false,selectedDecor=null;
let selected='vocabulary',view='today',sample=false,previewPlants=[],previewDecor=[],sampleData=sampleGarden(),camera={x:0,y:0,z:1},audioContext,toastTimer,lastDay=dayKey(Date.now()),lastGrowthStage=-1;
function save(){window.GroveNative?.save(state);try{localStorage.setItem(KEY,JSON.stringify(state));}catch{if(storageOK)toast('Your browser could not save this garden.');storageOK=false;}}
function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,5500);}
function bell(){if(!state.settings.sound)return;try{audioContext??=new (window.AudioContext||window.webkitAudioContext)();audioContext.resume();[523.25,659.25,783.99].forEach((freq,i)=>{const o=audioContext.createOscillator(),g=audioContext.createGain(),t=audioContext.currentTime+i*.33;o.type='sine';o.frequency.value=freq;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.09,t+.015);g.gain.exponentialRampToValueAtTime(.001,t+1.3);o.connect(g);g.connect(audioContext.destination);o.start(t);o.stop(t+1.4);});}catch{}}
function unlockAudio(){try{audioContext??=new (window.AudioContext||window.webkitAudioContext)();audioContext.resume();}catch{}}
function finish(early=false){
 const active=state.active;if(!active||(!early&&active.paused))return;
 if(active.kind==='break'){state.active=null;save();render();if(!window.GroveNative||Date.now()-active.endsAt<2000)bell();toast('Your break is complete. Ready for a little more growth?');return;}
 const completion=early?Date.now():active.endsAt,before=active.preview?previewPlants:state.sessions;
 const seconds=early?Math.max(0,Math.floor((active.durationMs-remaining(active))/1000)):active.durationMs/1000;
 const s=makeSession(active.category,seconds,before,completion,Math.floor(Math.random()*1e9),active.species);s.endedEarly=early;
 const after=[...before,s],gifts=rewards(before,after,completion);
 if(active.preview){previewPlants=after;previewDecor.push(...gifts);toast(`${s.species} grown in preview. Your history is unchanged.`);}
 else{state.sessions=after;state.decor.push(...gifts);const goalJustCompleted=!progress(before,completion).balanced&&progress(after,completion).balanced;toast(`${s.species} planted · +${s.earned} Dewdrops. ${goalJustCompleted?'All four types complete! Further sessions today earn 20.':'Take a five-minute break whenever you like.'}`);}
 $('end-dialog').close();$('abandon-dialog').close();state.active=null;save();if(early||!window.GroveNative||Date.now()-completion<2000)bell();render();
}
function startBreak(){if(state.active)return;unlockAudio();state.active={kind:'break',durationMs:300000,endsAt:Date.now()+300000,remainingMs:300000,paused:false};sample=false;save();render();setView('biome');}
function endBreak(){if(state.active?.kind!=='break')return;state.active=null;save();render();toast('Break finished. Your garden is ready when you are.');}
function pauseActive(){const a=state.active;if(!a)return;if(!a.paused&&remaining(a)<=0){finish();return;}if(a.paused){a.endsAt=Date.now()+a.remainingMs;a.paused=false;}else{a.remainingMs=remaining(a);a.paused=true;}save();render();}
function start(preview=false){if(state.active)return;unlockAudio();const durationMs=preview?10000:state.settings.minutes*60000;state.active={category:selected,species:pickSpecies(selected,preview?[...state.sessions,...previewPlants]:state.sessions,state.seedChoices[selected]),preview,durationMs,endsAt:Date.now()+durationMs,paused:false,remainingMs:durationMs};save();render();}
function tick(){
 if(state.active&&!state.active.paused&&remaining(state.active)<=0)finish();
 if(lastDay!==dayKey(Date.now())){lastDay=dayKey(Date.now());render();}
 if(state.active){const active=state.active,left=remaining(active),seconds=Math.ceil(left/1000),text=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
 $(active.kind==='break'?'break-timer':'timer').textContent=text;document.title=`${text} · ${active.kind==='break'?'Break · ':''}Pomodoro Grove`;
 if(active.kind!=='break'){const stage=Math.min(4,Math.max(0,Math.floor((1-left/active.durationMs)*5)));if(stage!==lastGrowthStage){lastGrowthStage=stage;drawToday();}}
 }else{lastGrowthStage=-1;document.title='Pomodoro Grove';}
}
function render(){
 setWindTime(animationTime,motionOn());applyBiome();renderShop();const p=progress(state.sessions),resting=state.active?.kind==='break',active=resting?null:state.active;
 $('today-date').textContent=new Date().toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'}).toUpperCase();
 $('choose').hidden=!!state.active;$('focus').hidden=!active;$('daily').hidden=!!active;
 $('headline').innerHTML=resting?'A little time to rest.':active?'A moment to grow.':p.balanced?'A good day,<br>gently grown.':'A little time.<br>A little growth.';
 $('subline').textContent=resting?'Let your garden keep you company.':active?`Growing ${categories[active.category].plant.toLowerCase()}.`:p.count?'Every little bit belongs here.':'Make space for something good.';
 $('goal-dots').replaceChildren(...Object.entries(categories).map(([key,cat])=>{const item=document.createElement('span');item.className='goal-type';const dot=document.createElement('i');dot.style.setProperty('--type-color',cat.color);dot.className=p.types.has(key)?'filled':'';dot.setAttribute('aria-hidden','true');const label=document.createElement('small');label.textContent=cat.label;item.append(dot,label);item.setAttribute('aria-label',cat.label+(p.types.has(key)?': complete':': still to grow'));return item;}));
 $('goal-dots').setAttribute('aria-label',`${p.types.size} of 4 Pomodoro types complete today`);
 $('goal-label').textContent=p.balanced?'4 of 4 types · daily goal complete':`${p.types.size} of 4 types today`;
 $('start').innerHTML=`Begin · ${state.settings.minutes} minutes <span aria-hidden="true">→</span>`;
 $('balance-note').textContent=p.balanced?'A balanced day. Your butterfly is here.':'One of each type completes your daily goal.';
 $('scene-caption').textContent=resting?'A quiet moment in your garden.':active?(active.preview?'A preview of what you’ll grow.':'One session. One new plant.'):todaySessions(state.sessions).length?'A little piece of today.':previewPlants.length?'Preview plants · your real garden is waiting.':'Your next plant · finish a session to grow it.';
 if(active){$('focus-category').textContent=categories[active.category].label.toUpperCase();$('pause').textContent=active.paused?'Resume':'Pause';$('timer-status').textContent=active.paused?'Take your time. It’s safe here.':'A quiet moment, just for you.';$('preview-label').hidden=!active.preview;}
 $('break-panel').hidden=!resting;$('take-break').hidden=!!state.active;
 if(resting){$('break-pause').textContent=state.active.paused?'Resume':'Pause';$('break-status').textContent=state.active.paused?'Break paused':'Five minutes to breathe';}
 renderBiomeInfo();drawToday();if(view==='biome')drawWorld();tick();
}
function setView(next){view=next;$('today-view').hidden=next!=='today';$('biome-view').hidden=next!=='biome';$('shop-view').hidden=next!=='shop';for(const key of ['today','biome','shop']){$(key+'-tab').classList.toggle('active',key===next);if(key===next)$(key+'-tab').setAttribute('aria-current','page');else $(key+'-tab').removeAttribute('aria-current');}if(next==='biome')fit();else if(next==='shop')renderShop();else drawToday();}
function canvasContext(canvas){const rect=canvas.getBoundingClientRect(),dpr=Math.min(2,window.devicePixelRatio||1);if(!rect.width||!rect.height)return null;const width=Math.round(rect.width*dpr),height=Math.round(rect.height*dpr);if(canvas.width!==width)canvas.width=width;if(canvas.height!==height)canvas.height=height;const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,rect.width,rect.height);return {c,w:rect.width,h:rect.height};}
function drawToday(){
 const data=canvasContext($('today-canvas'));if(!data)return;const {c,w,h}=data;
 const grown=todaySessions(state.sessions),plants=(grown.length?grown:previewPlants).slice(-9);
 const arranged=plants.map((p,i)=>({...p,x:(i%3-1)*94,y:Math.floor(i/3)*45}));
 const active=state.active?.kind==='break'?null:state.active;
 const hero=!arranged.length;
 const focusPlant={category:active?.category||selected,species:active?.species||chosenSpecies(selected),x:hero?0:155,y:hero?0:55};
 const all=hero||active?[...arranged,focusPlant]:arranged;
 let left=-180,right=180,top=-160,bottom=100;
 for(const p of all){const b=plantBounds(p);left=Math.min(left,b.left-15);right=Math.max(right,b.right+15);top=Math.min(top,b.top-15);bottom=Math.max(bottom,b.bottom+30);}
 const scale=Math.min((w-32)/(right-left),(h-54)/(bottom-top),hero?1.25:1);
 c.save();c.translate(w/2-(left+right)/2*scale,18-top*scale);c.scale(scale,scale);
 arranged.sort((a,b)=>a.y-b.y).forEach(p=>drawPlant(c,p));
 if(active){const ratio=1-remaining(active)/active.durationMs;const stages=['Seed','Sprout','Bud','Growing','Bloom'];const stage=stages[Math.min(4,Math.max(0,Math.floor(ratio*5)))];if(ratio>=.8)drawPlant(c,focusPlant);else drawGrowthStage(c,stage,focusPlant.x,focusPlant.y,1);}
 else if(hero)drawPlant(c,focusPlant);
 if(progress(state.sessions).balanced)drawDecor(c,{kind:'butterfly',x:35,y:-35});c.restore();weather(c,w,h);
}
function worldData(){return sample?sampleData:{sessions:state.sessions,decor:state.decor};}
function renderBiomeInfo(){const data=worldData();$('sample-badge').hidden=!sample;$('sample-button').textContent=sample?'Return to your garden':'Explore a sample grove';$('biome-kicker').textContent=sample?'A GLIMPSE OF WHAT YOU CAN GROW':'YOUR GROWING WORLD';$('biome-count').textContent=sample?'An example of 24 days of focused moments.':state.sessions.length?`${state.sessions.length} plants · ${new Set(state.sessions.map(s=>s.species)).size} species · all yours`:'Every session leaves something lovely.';$('world-empty').hidden=data.sessions.length>0||data.decor.some(d=>d.purchased)||!!placing;$('placement-bar').hidden=!placing;$('edit-tools').hidden=!editGarden||sample;$('edit-garden').textContent=editGarden?'Done decorating':'Arrange garden';renderInventory();}
function fit(){const canvas=$('biome-canvas'),rect=canvas.getBoundingClientRect(),data=worldData();if(!rect.width)return;let minX=-120,maxX=120,minY=-130,maxY=70;for(const p of data.sessions){const b=plantBounds(p);minX=Math.min(minX,b.left);maxX=Math.max(maxX,b.right);minY=Math.min(minY,b.top);maxY=Math.max(maxY,b.bottom);}for(const d of data.decor.filter(d=>d.purchased)){const b=decorBounds(d);minX=Math.min(minX,b.left);maxX=Math.max(maxX,b.right);minY=Math.min(minY,b.top);maxY=Math.max(maxY,b.bottom);}const terrain=Math.max(176,Math.sqrt(data.sessions.length)*56);minX=Math.min(minX,-terrain);maxX=Math.max(maxX,terrain);minY=Math.min(minY,-terrain*.6);maxY=Math.max(maxY,terrain*.6);camera.z=Math.min(1.65,(rect.width-60)/(maxX-minX),(rect.height-110)/(maxY-minY));camera.x=-(maxX+minX)/2*camera.z;camera.y=-(maxY+minY)/2*camera.z-15;drawWorld();}
function drawWorld(){if(view!=='biome')return;const data=canvasContext($('biome-canvas'));if(!data)return;const {c,w,h}=data,world=worldData();c.save();c.translate(w/2+camera.x,h/2+camera.y);c.scale(camera.z,camera.z);world.decor.filter(p=>decorCatalog.find(i=>i.id===p.kind)?.group==='paths').forEach(p=>drawShopDecor(c,p));[...world.sessions.map(p=>({...p,primary:true})),...world.decor.filter(p=>decorCatalog.find(i=>i.id===p.kind)?.group!=='paths')].sort((a,b)=>a.y-b.y).forEach(p=>p.primary?drawPlant(c,p):p.purchased?drawShopDecor(c,p):drawDecor(c,p));c.restore();weather(c,w,h);}
function zoom(factor,px,py){const rect=$('biome-canvas').getBoundingClientRect();px??=rect.width/2;py??=rect.height/2;const old=camera.z,newZ=Math.max(.12,Math.min(4,old*factor)),ratio=newZ/old;camera.x=(camera.x-(px-rect.width/2))*ratio+(px-rect.width/2);camera.y=(camera.y-(py-rect.height/2))*ratio+(py-rect.height/2);camera.z=newZ;$('plant-detail').hidden=true;drawWorld();}
function inspect(px,py){const rect=$('biome-canvas').getBoundingClientRect(),x=(px-rect.width/2-camera.x)/camera.z,y=(py-rect.height/2-camera.y)/camera.z;const closest=worldData().sessions.filter(p=>x>=plantBounds(p).left&&x<=plantBounds(p).right&&y<=plantBounds(p).bottom&&y>=plantBounds(p).top).sort((a,b)=>b.y-a.y)[0];if(!closest){$('plant-detail').hidden=true;return;}$('plant-detail').replaceChildren();const title=document.createElement('strong'),info=document.createElement('small');title.textContent=closest.species;info.textContent=`${categories[closest.category].label} · ${Math.round(closest.seconds/60)} min · ${new Date(closest.completedAt).toLocaleDateString()}`;$('plant-detail').append(title,info);$('plant-detail').hidden=false;}
function stats(){const summary=practiceSummary(state.sessions);$('stats-content').replaceChildren();
 for(const [key,label] of [['total','All time'],['today','Today'],['yesterday','Yesterday']]){const data=summary[key],section=document.createElement('section');section.className='practice-summary';const heading=document.createElement('h3');heading.textContent=label;const plants=document.createElement('p');plants.className='plants-total';plants.textContent=`${data.plants} plants grown`;const minutes=document.createElement('p');minutes.textContent=`${data.minutes} minutes of quiet practice`;section.append(heading,plants,minutes);if(key!=='total'){const goal=document.createElement('p');goal.className='practice-goal';goal.textContent=`${data.types} of 4 daily types completed`;section.append(goal);}$('stats-content').append(section);}
 $('stats').showModal();}
function drawCategoryIcons(){document.querySelectorAll('[data-category]').forEach(button=>{const category=button.dataset.category,canvas=button.querySelector('canvas'),c=canvas.getContext('2d');canvas.width=200;canvas.height=190;c.setTransform(2,0,0,2,0,0);c.clearRect(0,0,100,95);drawPlantInBox(c,{category,species:chosenSpecies(category)},12,8,76,78);});}
function renderShop(){
 $('coin-count').textContent=dewdrops(state);$('shop-balance').textContent=dewdrops(state)+' Dewdrops';
 const grid=$('shop-grid');grid.replaceChildren();
 for(const item of decorCatalog.filter(i=>shopFilter==='all'||i.group===shopFilter)){
 const card=document.createElement('article');card.className='shop-card';
 const canvas=document.createElement('canvas');canvas.width=280;canvas.height=240;canvas.setAttribute('aria-label',item.name);
 const c=canvas.getContext('2d');const bounds=decorBounds({kind:item.id,x:0,y:0});drawShopDecor(c,{kind:item.id,x:140,y:210},Math.min(1.65,160/item.height,224/(bounds.right-bounds.left)));
 const label=document.createElement('small');label.textContent=({paths:'PATHS & TILES',water:'WATER FEATURES',structures:'GARDEN STRUCTURES',landmarks:'BIG PURCHASES'})[item.group];
 const title=document.createElement('h2');title.textContent=item.name;
 const desc=document.createElement('p');desc.className='item-description';desc.textContent=item.description;
 const button=document.createElement('button');button.className='shop-buy';button.dataset.item=item.id;button.textContent=TEST_MODE?'Add · Free':'Buy · '+item.price+' Dewdrops';button.disabled=!TEST_MODE&&dewdrops(state)<item.price;
 button.onclick=()=>{if(!buyDecoration(state,item.id,TEST_MODE))return;save();renderShop();toast(item.name+' added to your basket. Choose Place to put it in your garden.');};
 const count=state.decorShop.inventory[item.id]||0;const place=document.createElement('button');place.className='text-button';place.textContent='Place · '+count+' in basket';place.disabled=!count;place.onclick=()=>beginPlacement(item.id);
 card.append(canvas,label,title,desc,button,place);grid.append(card);
 }
 if(shopFilter==='all'||shopFilter==='biomes')for(const biome of biomeCatalog){const owned=state.biomes.owned.includes(biome.id),active=state.biomes.active===biome.id,card=document.createElement('article');card.className='shop-card biome-card';const preview=document.createElement('img');preview.className='biome-preview';preview.src=biomeImages[biome.id];preview.alt=biome.name+' scenery';preview.decoding='async';const label=document.createElement('small');label.textContent=biome.time.toUpperCase()+' · '+biome.weather.toUpperCase();const name=document.createElement('h2');name.textContent=biome.name;const desc=document.createElement('p');desc.className='item-description';desc.textContent=biome.description;const button=document.createElement('button');button.className='shop-buy';button.textContent=active?'Active biome':owned?'Use biome':TEST_MODE?'Get biome · Free':'Unlock · '+biome.price+' Dewdrops';button.disabled=active||(!TEST_MODE&&!owned&&dewdrops(state)<biome.price);button.onclick=()=>{if(!owned&&!buyBiome(state,biome.id,TEST_MODE))return;previewBiome=null;state.biomes.active=biome.id;save();applyBiome();renderShop();drawToday();drawWorld();toast(biome.name+' is now your garden biome.');};const tryButton=document.createElement('button');tryButton.className='text-button';tryButton.textContent='Preview biome';tryButton.onclick=()=>{previewBiome=biome.id;applyBiome();setView('biome');renderBiomeInfo();};card.append(preview,label,name,desc,button,tryButton);grid.append(card);}
 renderInventory();
}
function renderInventory(){const box=$('inventory');box.replaceChildren();for(const item of decorCatalog){const count=state.decorShop.inventory[item.id]||0;if(!count)continue;const b=document.createElement('button');b.className='pill';b.textContent=item.name+' ×'+count;b.onclick=()=>beginPlacement(item.id);box.append(b);}if(!box.children.length){const note=document.createElement('span');note.textContent='Your basket is empty. Pick up decorations in the shop.';box.append(note);}}
function beginPlacement(kind){if(!(state.decorShop.inventory[kind]>0))return;sample=false;editGarden=true;placing={kind};selectedDecor=null;$('placement-label').textContent='Tap the garden to place your '+decorCatalog.find(i=>i.id===kind).name.toLowerCase()+'.';setView('biome');renderBiomeInfo();}
function gardenTap(px,py){const rect=$('biome-canvas').getBoundingClientRect(),x=Math.round(((px-rect.width/2-camera.x)/camera.z)/20)*20,y=Math.round(((py-rect.height/2-camera.y)/camera.z)/20)*20;
 if(sample){inspect(px,py);return;}
 if(placing){if(placing.moveId){const item=state.decor.find(d=>d.id===placing.moveId);if(item){item.x=x;item.y=y;}}else placeDecoration(state,placing.kind,x,y,'decor-'+Date.now()+'-'+Math.random().toString(36).slice(2,7));placing=null;save();renderShop();renderBiomeInfo();fit();return;}
 if(editGarden){const hit=state.decor.filter(d=>d.purchased).sort((a,b)=>b.y-a.y).find(d=>{const b=decorBounds(d);return x>=b.left&&x<=b.right&&y>=b.top&&y<=b.bottom;});selectedDecor=hit?.id||null;$('move-decor').disabled=!hit;$('store-decor').disabled=!hit;$('selected-decor').textContent=hit?decorCatalog.find(i=>i.id===hit.kind).name:'Tap a decoration to move it or put it away.';return;}
 inspect(px,py);
}
$('edit-garden').onclick=()=>{sample=false;editGarden=!editGarden;placing=null;selectedDecor=null;$('move-decor').disabled=true;$('store-decor').disabled=true;renderBiomeInfo();fit();};
$('cancel-placement').onclick=()=>{placing=null;renderBiomeInfo();};
$('move-decor').onclick=()=>{const item=state.decor.find(d=>d.id===selectedDecor);if(!item)return;placing={kind:item.kind,moveId:item.id};$('placement-label').textContent='Tap a new spot for this decoration.';renderBiomeInfo();};
$('store-decor').onclick=()=>{if(!storeDecoration(state,selectedDecor))return;selectedDecor=null;save();$('move-decor').disabled=true;$('store-decor').disabled=true;$('selected-decor').textContent='Returned to your basket.';render();fit();};
$('exit-biome-preview').onclick=()=>{previewBiome=null;applyBiome();drawToday();drawWorld();};
$('shop-tab').onclick=()=>setView('shop');$('wallet').onclick=()=>setView('shop');$('stats-tab').onclick=()=>stats();
document.querySelectorAll('[data-shop-filter]').forEach(b=>b.onclick=()=>{shopFilter=b.dataset.shopFilter;document.querySelectorAll('[data-shop-filter]').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',String(x===b));});renderShop();});
function selectCategory(button){selected=button.dataset.category;document.querySelectorAll('[data-category]').forEach(b=>{b.classList.toggle('selected',b===button);b.setAttribute('aria-pressed',String(b===button));});$('seed-choice').textContent='Seed: '+(state.seedChoices[selected]||'Random · different each time')+' · Change';drawToday();}
function openSeeds(category){$('seed-title').textContent=categories[category].plant+' · choose a seed';const grid=$('seed-grid');grid.replaceChildren();for(const name of [null,...categories[category].species]){const button=document.createElement('button');button.className='seed-option';button.setAttribute('aria-pressed',String((state.seedChoices[category]||null)===name));const label=document.createElement('span');label.textContent=name||'Random · no repeats';if(name){const canvas=document.createElement('canvas');canvas.width=180;canvas.height=150;drawPlantInBox(canvas.getContext('2d'),{category,species:name},12,8,156,134);button.append(canvas);}button.append(label);button.onclick=()=>{state.seedChoices[category]=name;save();$('seed-dialog').close();drawCategoryIcons();$('seed-choice').textContent='Seed: '+(state.seedChoices[selected]||'Random · different each time')+' · Change';drawToday();};grid.append(button);}$('seed-dialog').showModal();}
document.querySelectorAll('[data-category]').forEach(button=>{let hold=null,held=false,origin;const cancel=()=>{clearTimeout(hold);hold=null;};button.onclick=()=>{if(held){held=false;return;}selectCategory(button);};button.onpointerdown=e=>{if(e.button!==0)return;held=false;origin={x:e.clientX,y:e.clientY};hold=setTimeout(()=>{held=true;selectCategory(button);openSeeds(button.dataset.category);},500);};button.onpointermove=e=>{if(origin&&Math.hypot(e.clientX-origin.x,e.clientY-origin.y)>10)cancel();};button.onpointerup=cancel;button.onpointercancel=cancel;button.onpointerleave=cancel;button.oncontextmenu=e=>{e.preventDefault();cancel();held=true;selectCategory(button);openSeeds(button.dataset.category);};button.onkeydown=e=>{if(e.key==='Enter'&&e.shiftKey){e.preventDefault();selectCategory(button);openSeeds(button.dataset.category);}};});
$('seed-choice').onclick=()=>openSeeds(selected);$('close-seeds').onclick=()=>$('seed-dialog').close();
$('try-preview').hidden=!TEST_MODE;

const themes={peach:'Peach pink, mint hills, and a pastel crayon world.',sunshine:'Butter yellow, aqua skies, and a sunny crayon world.',lilac:'Lavender, berry pink, and a dreamy crayon world.'};
function applyTheme(theme,persist=false){if(!themes[theme])theme='peach';state.settings.theme=theme;document.body.dataset.theme=theme;setArtTheme(theme);$('design-description').textContent=themes[theme];document.querySelectorAll('.theme-choice[data-theme]').forEach(button=>{button.classList.toggle('active',button.dataset.theme===theme);button.setAttribute('aria-pressed',String(button.dataset.theme===theme));});drawCategoryIcons();drawToday();drawWorld();if(persist)save();}
document.querySelectorAll('.theme-choice[data-theme]').forEach(button=>{button.onclick=()=>applyTheme(button.dataset.theme,true);});
applyTheme(state.settings.theme);
const begin=async(preview=false)=>{await window.GroveNative?.prepare();start(preview);};$('start').onclick=()=>window.GroveNative?begin():start();$('try-preview').onclick=()=>window.GroveNative?begin(true):start(true);$('today-tab').onclick=() =>setView('today');$('biome-tab').onclick=()=>setView('biome');$('return-today').onclick=()=>setView('today');document.querySelector('.wordmark').onclick=e=>{e.preventDefault();setView('today');};
$('pause').onclick=pauseActive;$('break-pause').onclick=pauseActive;
$('take-break').onclick=()=>window.GroveNative?window.GroveNative.prepare().then(startBreak):startBreak();$('break-garden').onclick=()=>setView('biome');$('break-end').onclick=endBreak;
$('end').onclick=()=>$('end-dialog').showModal();$('keep-focusing').onclick=()=>$('end-dialog').close();$('confirm-end').onclick=()=>{$('end-dialog').close();if(state.active?.kind!=='break')finish(true);};
$('abandon').onclick=()=>$('abandon-dialog').showModal();$('keep-session').onclick=()=>$('abandon-dialog').close();$('confirm-abandon').onclick=()=>{if(state.active?.kind==='break')return;state.active=null;save();$('abandon-dialog').close();render();toast('Session abandoned. No plant or Dewdrops awarded.');};
$('settings-button').onclick=()=>{$('duration').value=state.settings.minutes;$('sound').checked=state.settings.sound;$('motion').checked=state.settings.motion;$('settings').showModal();};$('save-settings').onclick=()=>{const minutes=Number($('duration').value);if(!Number.isInteger(minutes)||minutes<5||minutes>120){$('duration').reportValidity();return;}state.settings={...state.settings,minutes,sound:$('sound').checked,motion:$('motion').checked};save();$('settings').close();render();};$('bell-preview').onclick=()=>{unlockAudio();const enabled=state.settings.sound;state.settings.sound=true;bell();state.settings.sound=enabled;};$('stats-button').onclick=stats;$('close-stats').onclick=()=>$('stats').close();
$('sample-button').onclick=()=>{sample=!sample;placing=null;editGarden=false;$('plant-detail').hidden=true;renderBiomeInfo();fit();};$('zoom-in').onclick=()=>zoom(1.25);$('zoom-out').onclick=()=>zoom(.8);$('fit').onclick=fit;
const pointers=new Map();let dragStart=null,lastPinch=0,moved=false;
$('biome-canvas').addEventListener('pointerdown',e=>{const canvas=e.currentTarget;canvas.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});dragStart={x:e.clientX,y:e.clientY};moved=false;if(pointers.size===2){const p=[...pointers.values()];lastPinch=Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y);}});
$('biome-canvas').addEventListener('pointermove',e=>{const old=pointers.get(e.pointerId);if(!old)return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(dragStart&&Math.hypot(e.clientX-dragStart.x,e.clientY-dragStart.y)>5)moved=true;if(pointers.size===2){const p=[...pointers.values()],distance=Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y),rect=e.currentTarget.getBoundingClientRect();if(lastPinch>0)zoom(distance/lastPinch,(p[0].x+p[1].x)/2-rect.left,(p[0].y+p[1].y)/2-rect.top);lastPinch=distance;}else{camera.x+=e.clientX-old.x;camera.y+=e.clientY-old.y;$('plant-detail').hidden=true;drawWorld();}});
$('biome-canvas').addEventListener('pointerup',e=>{if(!moved&&pointers.size===1){const r=e.currentTarget.getBoundingClientRect();gardenTap(e.clientX-r.left,e.clientY-r.top);}pointers.delete(e.pointerId);lastPinch=0;});$('biome-canvas').addEventListener('pointercancel',e=>pointers.delete(e.pointerId));$('biome-canvas').addEventListener('wheel',e=>{e.preventDefault();const r=e.currentTarget.getBoundingClientRect();zoom(Math.exp(-e.deltaY*.0015),e.clientX-r.left,e.clientY-r.top);},{passive:false});
let swipeStart; $('today-view').addEventListener('touchstart',e=>{if(e.target.closest('button'))return;swipeStart={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});$('today-view').addEventListener('touchend',e=>{if(!swipeStart)return;const dx=e.changedTouches[0].clientX-swipeStart.x,dy=e.changedTouches[0].clientY-swipeStart.y;if(dx>85&&Math.abs(dy)<60)setView('biome');swipeStart=null;},{passive:true});
window.addEventListener('resize',()=>{drawToday();if(view==='biome')fit();});document.addEventListener('visibilitychange',()=>{if(!document.hidden){tick();render();}});window.addEventListener('pageshow',()=>tick());window.addEventListener('grove-resume',()=>{tick();render();});
// A session crossing midnight belongs to the day it completed, even after reopening.
reducedMotion?.addEventListener?.('change',()=>{setWindTime(animationTime,motionOn());drawToday();drawWorld();});
render();if(state.active?.kind==='break')setView('biome');setInterval(tick,250);if(!storageOK)toast('Browser storage is unavailable; progress may not be saved.');

loadPlantArt().then(()=>{drawCategoryIcons();drawToday();drawWorld();renderShop();});

// Render only the visible scene, capped at 24 fps; never rebuild shop DOM per frame.
let lastFrame=0;
function animate(timestamp){if(!document.hidden&&motionOn()&&timestamp-lastFrame>=1000/24){lastFrame=timestamp;animationTime=timestamp/1000;setWindTime(animationTime,motionOn());if(view==='today')drawToday();else if(view==='biome')drawWorld();}window.requestAnimationFrame(animate);}
if(window.requestAnimationFrame)window.requestAnimationFrame(animate);
