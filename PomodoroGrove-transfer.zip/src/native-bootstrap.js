import {Capacitor} from '@capacitor/core';
import {Preferences} from '@capacitor/preferences';
import {LocalNotifications} from '@capacitor/local-notifications';
import {App} from '@capacitor/app';
import {createSync} from './native-sync.js';
const key='little-grove-v1',id=71001;
if(Capacitor.isNativePlatform()){
 document.body.classList.add('native-app');
 const note=document.querySelector('.storage-note');
 note.textContent='Your garden is saved on this iPhone and works offline. Allow notifications for a reminder when your phone is locked. Your plant appears when you return.';
 try{const {value}=await Preferences.get({key});if(value){const saved=JSON.parse(value);if(!Array.isArray(saved.sessions)||!Array.isArray(saved.decor)||!saved.settings)throw Error('Invalid garden');localStorage.setItem(key,value);}}
 catch(error){document.body.innerHTML='<main style="padding:40px"><h1>Your garden could not be loaded.</h1><p>Please close and reopen the app. Your saved garden has not been changed.</p></main>';throw error;}
 const report=()=>{note.textContent='There was a problem saving your garden or scheduling its reminder. Keep the app open and try again.';};
 const sync=createSync({persist:value=>Preferences.set({key,value}),cancel:()=>LocalNotifications.cancel({notifications:[{id}]}),schedule:async(a,sound)=>{
  if((await LocalNotifications.checkPermissions()).display!=='granted')return;
  await LocalNotifications.schedule({notifications:[{id,title:a.kind==='break'?'A little time to grow.':a.preview?'Preview complete':'A little more life.',body:a.kind==='break'?'Your five-minute break is complete. Ready when you are.':a.preview?'Return to see your preview plant.':'Your focus session is complete. Come see what grew.',schedule:{at:new Date(a.endsAt)},...(sound?{sound:'grove-bell.wav'}:{})}]});
 },onError:report});
 window.GroveNative={save:sync,async prepare(){try{let p=await LocalNotifications.checkPermissions();if(p.display==='prompt')p=await LocalNotifications.requestPermissions();if(p.display!=='granted')note.textContent='Notifications are off. Enable them in iPhone Settings → Pomodoro Grove for lock-screen reminders.';}catch{report();}}};
 await App.addListener('appStateChange',({isActive})=>{if(isActive)window.dispatchEvent(new Event('grove-resume'));});
}
await import('./app.js');
