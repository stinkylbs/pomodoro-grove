#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != Darwin ]]; then
  echo 'An iOS IPA requires macOS with Xcode 26+. Use the included GitHub Actions workflow.' >&2
  exit 1
fi
npm run ios:sync
xcodebuild -project ios/App/App.xcodeproj -scheme App -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build/DerivedData \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' build
app_path='build/DerivedData/Build/Products/Release-iphoneos/App.app'
test -d "$app_path"
/usr/bin/file "$app_path/App" | /usr/bin/grep -q arm64
platform=$(/usr/libexec/PlistBuddy -c 'Print :DTPlatformName' "$app_path/Info.plist")
[[ "$platform" == iphoneos ]]
mkdir -p output
stage=$(mktemp -d "$PWD/build/ipa.XXXXXX")
trap 'rm -rf "$stage"' EXIT
mkdir "$stage/Payload"
ditto "$app_path" "$stage/Payload/App.app"
rm -f output/PomodoroGrove-unsigned.ipa
(cd "$stage" && /usr/bin/zip -qr "$OLDPWD/output/PomodoroGrove-unsigned.ipa" Payload)
echo 'Created output/PomodoroGrove-unsigned.ipa — sign and install using Sideloadly.'
