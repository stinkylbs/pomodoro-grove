import {cp,rm,readFile,writeFile} from 'node:fs/promises';
import {build} from 'esbuild';
await rm('dist',{recursive:true,force:true});
await cp('src','dist',{recursive:true});
await build({entryPoints:['src/native-bootstrap.js'],bundle:true,format:'esm',target:'safari15',outfile:'dist/native.js'});
let html=await readFile('dist/index.html','utf8');
await writeFile('dist/index.html',html.replace('src="app.js"','src="native.js"'));
