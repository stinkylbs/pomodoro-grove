from pathlib import Path
import re, base64, argparse
parser=argparse.ArgumentParser();parser.add_argument("--test",action="store_true");args=parser.parse_args()

root=Path(__file__).resolve().parents[1]
src=root/'src'
html=(src/'index.html').read_text()
css='\n'.join((src/f).read_text() for f in ('style.css','themes.css'))
js=[]
for f in ('core.js','storybook-art.js','art.js','app.js'):
    content=(src/f).read_text()
    content=re.sub(r'^import .*?;\s*$', '', content, flags=re.M)
    content=re.sub(r'\bexport\s+(?=(?:const|let|function|async function|class)\b)', '', content)
    if f=='art.js':
        content=content.replace('export {', '{')
    js.append('// '+f+'\n'+content)

combined='\n'.join(js)
# Embed the approved sprite PNGs as data URLs so the Windows demo stays one-click / one-file.
asset_urls={}
css_vars=[]
for index,asset in enumerate(sorted((src/'assets'/'storybook').glob('*.webp'))):
    if not asset.stat().st_size: raise ValueError('Empty asset: '+asset.name)
    rel='assets/storybook/'+asset.name
    data='data:image/webp;base64,'+base64.b64encode(asset.read_bytes()).decode('ascii')
    if rel in combined:
        asset_urls[rel]=data
        combined=combined.replace("'"+rel+"'",'EMBEDDED_ASSETS['+repr(rel)+']').replace('"'+rel+'"','EMBEDDED_ASSETS['+repr(rel)+']')
    if rel in css:
        var='--asset-'+str(index)
        css=css.replace("url('"+rel+"')",'var('+var+')')
        css_vars.append(var+':url('+data+')')
css=':root{'+ ';'.join(css_vars)+'}\n'+css
import json
missing=set(re.findall(r'assets/storybook/[a-z0-9-]+\.webp',combined))-set(asset_urls)
if missing: raise ValueError('Missing embedded assets: '+', '.join(sorted(missing)))
combined='window.GROVE_TEST_MODE='+str(args.test).lower()+';\nconst EMBEDDED_ASSETS='+json.dumps(asset_urls)+';\n'+combined

html=re.sub(r'<link rel="stylesheet" href="style.css"><link rel="stylesheet" href="themes.css">','<style>'+css+'</style>',html)
html=html.replace('<script type="module" src="app.js"></script>','<script>\n'+combined.replace('</script>','<\\/script>')+'\n</script>')
if not args.test:
    html=re.sub(r'<button id="try-preview".*?</button>','<button id="try-preview" hidden></button>',html)
output=root/('Pomodoro-Grove-Test.html' if args.test else 'Pomodoro-Grove.html')
output.write_text(html)
print('Created',output,output.stat().st_size,'bytes')
