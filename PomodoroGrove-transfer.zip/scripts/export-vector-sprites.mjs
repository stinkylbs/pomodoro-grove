import fs from 'node:fs';
import {drawShopDecor,drawDecor} from '../src/art.js';
const destination=process.argv[2];fs.mkdirSync(destination,{recursive:true});
for(const kind of ['brick','cobblestone','moss-stones','flower-border','wood-tiles','puddle','butterfly','mushroom','stone']){
 let output='',depth=0,path='';const c={fillStyle:'',strokeStyle:'',lineWidth:1,lineCap:'round',save(){output+='<g>';depth++;},restore(){output+='</g>';depth--;},translate(x,y){output+=`<g transform="translate(${x} ${y})">`;depth++;},scale(x,y){output+=`<g transform="scale(${x} ${y})">`;depth++;},beginPath(){path='';},moveTo(x,y){path+=`M${x} ${y}`;},lineTo(x,y){path+=`L${x} ${y}`;},ellipse(x,y,rx,ry){path+=`M${x-rx} ${y}a${rx} ${ry} 0 1 0 ${rx*2} 0a${rx} ${ry} 0 1 0 ${-rx*2} 0`;},fill(){output+=`<path d="${path}" fill="${this.fillStyle}"/>`;},stroke(){output+=`<path d="${path}" fill="none" stroke="${this.strokeStyle}" stroke-width="${this.lineWidth}" stroke-linecap="${this.lineCap}"/>`;},fillRect(x,y,w,h){output+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${this.fillStyle}"/>`;}};
 (['butterfly','mushroom','stone'].includes(kind)?drawDecor:drawShopDecor)(c,{kind,x:128,y:200},3);
 output+='</g>'.repeat(depth);fs.writeFileSync(`${destination}/${kind}.svg`,`<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256">${output}</svg>`);
}
