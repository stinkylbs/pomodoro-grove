# Pomodoro Grove

Open `Pomodoro-Grove.html` for the clean offline app. The separate `Pomodoro-Grove-Test.html` keeps the free shop and ten-second preview for testing. Neither displays a version label or the old shop instruction block.

## Daily focus and rewards

The daily goal is one Pomodoro of each type, shown with four labeled circles in a fixed order: Vocabulary (pink), Casual Reading (amber), Philosophy (mint), and News (lavender). A repeated type adds another plant but does not fill a different circle.

Each completed Pomodoro earns 2 Dewdrops until the daily goal is met. The session that completes the fourth distinct type earns 102 (2 plus a 100 bonus). Further sessions that local day earn 20 each. Existing saved earnings are preserved.

End early counts as a completed Pomodoro, grows the chosen plant, and awards the applicable currency. Stats records only actual unpaused focus time. Abandon adds nothing. The app prevents completion from being awarded twice.

## Garden breaks and Stats

Take a five-minute break to open the garden with a persistent countdown. Browse, pan, zoom, pause/resume or end the break. Breaks survive reopening and earn no plants, currency or focus minutes. Native notifications distinguish breaks from focus sessions.

Stats contains only all-time plants grown and quiet-practice minutes, plus Today and Yesterday totals and progress toward the four distinct daily types. Dates follow the device's local calendar.

## Seeds, shop and scenery

All 18 plant varieties are available from the start. Hold a Pomodoro type, right-click it, press Shift+Enter, or click Change seed. Random mode avoids repeating the previous variety for that type. Explicit choices persist.

There are 29 placeable shop decorations and six selectable biomes. All scenery now uses image elements, including shop cards; large embedded data URLs no longer pass through CSS custom properties. The six backgrounds are included in both offline builds. The ten refined sprites preserve alpha transparency and complete outlines. Gentle plant sway and weather respect reduced motion.

The clean app uses normal prices. The test build uses its own save key and keeps all purchases free. It copies the previous regular garden only when no test save exists. Existing regular and test saves remain separate.

## Validation

Run `npm test` for automated checks. Build the standalone app with `python3 scripts/build-windows-preview.py`; add `--test` for the free test build. The source package contains a configured iOS project, not a compiled IPA. Native device verification and live browser screenshots remain outstanding in this environment.

## Build an IPA with GitHub Actions

1. Create a private GitHub repository and commit this folder's contents, including `.github/workflows/ios-ipa.yml`. Do not include `node_modules` or generated build folders. GitHub Actions must be enabled and your account must have available macOS runner usage.
2. Open **Actions → Build iPhone IPA → Run workflow**.
3. After the run succeeds, download the **PomodoroGrove-iPhone** artifact and unzip it. It contains `PomodoroGrove-unsigned.ipa`.

The workflow uses a macOS runner with Xcode 26+, builds for a physical iPhone, and packages an unsigned IPA. It does not need your Apple ID, signing certificate, or Apple password. Sideloadly performs signing on your own computer.

## Install with Sideloadly

1. Download Sideloadly from https://sideloadly.io on your Mac or Windows computer. Follow its current prerequisite instructions; Windows requires Apple's web versions of iTunes and iCloud.
2. Connect your iPhone by USB, unlock it, and trust the computer.
3. Open Sideloadly, select your phone, drag in `PomodoroGrove-unsigned.ipa`, enter your Apple ID in Sideloadly, and start installation.
4. Follow iOS prompts to trust the developer and enable Developer Mode if requested.
5. Open Pomodoro Grove and start a five-minute break. Allow notifications, then lock your phone to check the completion reminder.

Free Apple accounts need re-signing every seven days. Configure Sideloadly's automatic refresh and keep your computer available for it. See its current instructions for USB/Wi-Fi pairing. Keep the same Apple ID and bundle identifier for updates; deleting the app deletes its on-device garden.

## Build on your own Mac

Requires Node.js 22+ and Xcode 26+ with iOS SDK support. The app supports iOS 15+.

```sh
npm ci
npm test
npm run ios:ipa
```

Output: `output/PomodoroGrove-unsigned.ipa`.
For Xcode editing: `npm run ios:sync` then `npm run ios:open`.


## Device checks

Verify a locked-phone completion, paused/resumed focus and break timers, rewarded early finish, abandonment, permission denied, relaunch, offline use, and updating over an existing installation. Browser sounds require an open tab; the native app schedules local notifications. This app stores data locally and does not sync devices.
